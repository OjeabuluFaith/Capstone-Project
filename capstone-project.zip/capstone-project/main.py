from scraper import Scraper
from dotenv import load_dotenv, dotenv_values
from db_manager import DatabaseManager

load_dotenv()
db_config = dotenv_values(".env")
print(db_config)


def main():
    # get total number of pages
    print("-->>> fetching total number of pages <<<--")
    pages_num = Scraper.get_pages_total()

    # get user's input of pages to be scraped
    pages_to_scrape = input(
        f"{pages_num} pages are available. How many will you like to scrape? ")
    print("\n")

    # scrape job listings under the specified pages
    no_of_pages_to_scrape = int(pages_to_scrape) if int(
        pages_to_scrape) <= pages_num else pages_num

    print(f"-->>> scraping {pages_to_scrape} pages. please wait. <<<---\n")

    job_listings = Scraper.extract_all_job_listings(no_of_pages_to_scrape)

    print(f"\n-->>> Scraping Completed <<<---\n")
    # save job listings to database
    # db_mgr = DatabaseManager(host=db_config["DB_HOST"], port=int(
    #     db_config["DB_PORT"]), name=db_config["DB_NAME"], user=db_config["DB_USER"], password=db_config["DB_PASS"])

    # print(f"\n-->>> saving to database. please wait. <<<---\n")
    # db_mgr.drop_job_listings_table()
    # db_mgr.create_job_listings_table()
    # db_mgr.add_job_listings_to_table(job_listings)

    # print(f"\n-->>> Job Listings Saved to Database <<<---\n")


if __name__ == '__main__':
    main()
